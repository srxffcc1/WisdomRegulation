package com.wisdomregulation.frame;

import android.view.View;

public interface OnCheckedChangeListener2{
	public void onCheckedChanged(View buttonView, boolean isChecked);
}