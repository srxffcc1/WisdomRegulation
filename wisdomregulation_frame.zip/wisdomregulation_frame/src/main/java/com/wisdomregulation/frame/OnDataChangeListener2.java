package com.wisdomregulation.frame;

public interface OnDataChangeListener2 {
	 void onDataChanged();
}