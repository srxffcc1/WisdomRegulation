package com.wisdomregulation.frame;

public interface OnDataChangeListener {
	 void onCheckedChanged();
}