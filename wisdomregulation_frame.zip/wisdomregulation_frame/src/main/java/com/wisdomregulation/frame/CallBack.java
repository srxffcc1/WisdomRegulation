package com.wisdomregulation.frame;

/**
 * 通用回调方法
 * @author King2016s
 *
 */
public 	interface CallBack {
	public void back(Object resultlist);
	
}
