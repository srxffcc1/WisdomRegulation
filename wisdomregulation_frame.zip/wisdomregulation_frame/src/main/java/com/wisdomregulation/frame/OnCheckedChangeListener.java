package com.wisdomregulation.frame;

import android.view.View;

public interface OnCheckedChangeListener{
	public void onCheckedChanged(View buttonView, boolean isChecked);
}