package com.wisdomregulation.frame;

public interface IAutoCheck {
	public void setOnCheckedChangeListener(OnCheckedChangeListener onCheckedChangeListener);
	public void setOnCheckedChangeListener2(OnCheckedChangeListener2 onCheckedChangeListener2);
}
