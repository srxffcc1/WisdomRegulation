package com.frame.zxing.decoding;

import com.frame.zxing.view.ViewfinderView;

/**
 * Created by KingGT80 on 2017/2/21.
 */

public interface ICaptureHander {

    ViewfinderView getViewfinderView();
}
