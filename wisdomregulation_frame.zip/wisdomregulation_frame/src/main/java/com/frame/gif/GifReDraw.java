package com.frame.gif;

public interface GifReDraw {

	public int reDraw();
}
