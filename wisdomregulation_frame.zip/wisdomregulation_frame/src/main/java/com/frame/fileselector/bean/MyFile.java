package com.frame.fileselector.bean;

import java.io.File;

public class MyFile {
	public boolean checked = false;//文件是否选中
	public File file;//文件对象的引用
}
